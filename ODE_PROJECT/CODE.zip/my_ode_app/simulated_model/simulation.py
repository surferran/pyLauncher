'''
the quad simulation functions.
'''

from myImports import *

def run_sim():
    '''
    '''
    print " entered 'run_sim()' "
    return 10110

if __name__ == '__main__':
    run_sim()
    pass
