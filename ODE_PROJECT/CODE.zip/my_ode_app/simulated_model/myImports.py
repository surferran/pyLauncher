'''
import settings for the Quad-Sim.
'''


import os
import numpy
import pandas
# import scipy
import bokeh

if __debug__:
    print "loaded packages , and their versions are :"
    # print "os: " + os.__version__
    print "numpy: " + numpy.__version__
    print "pandas: " + pandas.__version__
    # print "scipy: " + scipy.__version__
    print "bokeh: " + bokeh.__version__

import bokeh.plotting as bkPlt
import utils.myGUI as myGUI

import simulation as sim