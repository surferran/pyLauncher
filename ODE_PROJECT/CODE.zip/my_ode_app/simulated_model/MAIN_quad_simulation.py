'''
the quad simulation.
it describes a set of quadrotos with certain properties:
frame :
    arm length
    frame mass
    moments of inertia
    rigidity of the frame
motors+ESC (Electric Speed Controller):
    mass
    average rotation speed
    rpm-pwm-command relation
rotors:
    mass
    inertia
    rigidity
controller:
    PID type and constants.
    (its' mass assumed to be included in the frame)

optional:
    'mission' profile:
        race    (high pitch angle most of the time, high farward speed. tight manuevers)
        film    (mostly hovering. needs to be stable with interruptions, such as gust winds, constant high wind,
                    outer interuptions (maybe someone pushing it , when in person close by) )

quad build examples:
http://hobby-wing.com/arris-xsp-250b-rtf-flysky-fsi6.html

one can model the behaviour of (which i won't include here):
        gps reception and calculations
        battery consumption
        camera and visual preception quality
        frame rigidity - one can relate to (aero)elasticity of the frame , but i will treat it as rigid body.
            (if ,for example, frame is made out of carbon, and it is flat - there will be frame-arm bending during flight.
             if , let's say, the frame is made out of hollow tubes - it can be treated as rigid, because twisting, and bending,
                will be minimal)
        blades rigidity - aeroelasticity will not be handled here. the blades will be refered as rigid as well.
            (in reality it is probobly not so true.
              here, in small quadrotors, because of the very fast rotaion speeds, and small blades lenght - we can assume that)
        radio communication quality / disturbances.
        etc.
i will look on the dynamical behaviour of the quad, hence modeling:
        mass properties
        inertia properties
        the control system
        stability of the system with the chosen controller
        the responce of the electric motors (from PWM command to ESC responce, and to Motor's desired-RPM response)


'''

from myImports import *

def main():
    myGUI.open_main_htm_page()

if __name__ == '__main__':
    print "----- starting MAIN quad-sim call function -----"
    main()

    print "----- FINISHED MAIN quad-sim -----"


