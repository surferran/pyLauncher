'''
gui functions for the Quad-Sim
gui will be using web (html+JavaScript) framework.
'''

import sys
sys.path.append('../')

from myImports import *     # from .. import myImports

from bokeh.plotting import figure
from bokeh.resources import CDN
from bokeh.embed import file_html, components
from bokeh.io import output_file, show


def open_main_htm_page():
    '''
    '''
    print " entered 'htm_page()' "

    html_page_name = "quadMain.htm"


    # plot = figure()
    # plot.circle([1, 2], [3, 4])
    # html = file_html(plot, CDN, html_page_name)
    # script, div = components(plot)
    # Making a basic Bokeh line graph


    # prepare some data
    # df=pandas.read_csv("S1L6-data.csv")
    # x=df["x"]
    # y=df["y"]
    # df=pandas.read_csv("S1Ex2-bachelors.csv")
    df = pandas.read_csv("http://pythonhow.com/data/bachelors.csv")
    x = df["Year"]
    y = df["Engineering"]

    # prepare the output file
    output_file("Line_from_csv.html")

    # create a figure object
    f = figure()

    # create line plot
    f.line(x, y)

    # write the plot in the figure object
    show(f)

    #
    # plot = bkPlt.line(x, y)
    #
    # ##the following line refers to the bokeh installed on my home computer
    # print plot.create_html_snippet(
    #     static_path='/usr/local/lib/python2.7/site-packages/bokeh/server/static/')
    ##the following line refers to the bokeh installed on my remote computer
    # print plot.create_html_snippet(
    #           static_path='/opt/anaconda/lib/python2.7/site-packages/bokeh/server/static/')

    pass


def open_main_page(page_type='HTM'):
    if page_type=='HTM':
        open_main_htm_page()
    else:
        # open_main_wx_page()
        pass

if __name__ == '__main__':
    open_main_page('HTM')

