'''
gui functions for the Quad-Sim
gui will be using web (html+JavaScript) framework.
'''

import sys
sys.path.append('../')

from myImports import *     # from .. import myImports

from bokeh.plotting         import figure
from bokeh.resources        import CDN
from bokeh.embed            import file_html, components
from bokeh.io               import output_file, show, curdoc
from bokeh.models.widgets   import Slider, TextInput, Tabs, Button
from bokeh.layouts          import row, widgetbox

##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''
'''
    TODO:
    set start,value,end etc. as global variables
'''
##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''##''''''

motor_mass = Slider(title="motor_mass [kg]", start=0.1, value=1.0, end=5.0, step=0.1)
prop_mass  = Slider(title="prop_mass [kg]" , start=0.1, value=1.0, end=5.0, step=0.1)

def open_main_htm_page():
    '''
    '''
    global motor_mass, prop_mass

    print " entered 'htm_page()' "

    # prepare the output file
    # output_file("quadSim_inputs.html")


    # creating slide and text controls and button for initiating.

    # motor_mass = Slider(title="motor_mass [kg]", start=0.010, value=1.0, end=5.0, step=0.1)
    frame_mass = Slider(title="frame_mass [kg]", start=0.10, value=1.0, end=5.0, step=0.1)
    # prop_mass  = Slider(title="prop_mass [kg]" , start=0.010, value=1.0, end=5.0, step=0.1)
    arm_length = Slider(title="arm_length [m]" , start=0.10, value=1.0, end=5.0, step=0.1)
    prop_aero_cl_alpha = Slider(title="prop_aero_cl_alpha [-]", start=0.10, value=1.0, end=5.0, step=0.1)
    prop_aero_cd_alpha = Slider(title="prop_aero_cd_alpha [-]", start=0.10, value=1.0, end=5.0, step=0.1)

    user_inputs = [motor_mass,  frame_mass , prop_mass , arm_length , prop_aero_cl_alpha, prop_aero_cd_alpha ]

    inputs = widgetbox(user_inputs)

    sim_activate_btn = Button(label="Activate Sim", button_type="success")
    sim_activate_btn.on_click(activate_simulation_fnc)

    user_controls = [sim_activate_btn]
    controls = widgetbox(user_controls)

    page_cnotent = row(inputs, controls, width=800)

    curdoc().add_root(page_cnotent)
    curdoc().title = "QuadRotor simulation"

    # write the plot in the figure object
    # show(page_cnotent)


def open_main_page(page_type='HTM'):
    if page_type=='HTM':
        open_main_htm_page()
    else:
        # open_main_wx_page()
        pass

def activate_simulation_fnc():
    global motor_mass, prop_mass

    print "stage 1"
    motor_mass.value = 4

    tmp = sim.run_sim()

    print "returned value from calling sim is : " + str(tmp)

    prop_mass.value = 2
    print "stage 2"


# if __name__ == '__main__':
#     open_main_page('HTM')


print " name of script operator is :" + __name__
open_main_page('HTM')