'''
the quad model.
'''

from myImports import *

def quad():
    '''
    it is an assembly of:
    frame-controller-ESC-motor-propellor
    '''
    print " entered 'quad()' "

if __name__ == '__main__':
    # main()
    pass
