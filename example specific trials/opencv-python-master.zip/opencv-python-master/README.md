# opencv-python
Automatically exported from code.google.com/p/opencv-python


Complete guide how project was developed and how to get installed. 

https://docs.google.com/file/d/0B0m3f9uIC1OyYjA2NTY5YmItZGQ0NC00NmViLWE5ODAtZTRkMmQzNDE0NGYw/edit?hl=es
