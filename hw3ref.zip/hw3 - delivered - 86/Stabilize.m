function [StabilizedFrames]=Stabilize(frames,TrReff,TtReff)
% stabilizing the given frames. and displaying the outcome
% frames - images to stabilize. according to Rotation and Transation.
% TrReff - array of rotation matrixes. base image to # nonstabilized frame
% TtReff - array of translation matrixes. base image to # nonstabilized frame
% % frames=imgs(:,:,2:7); % for debugging--
StabilizedFrames=frames(:,:,1);    % just for format %[];
for j=1:size(frames,3)            % pass over all the frames to stabilize
    StabCoords=zeros(size(frames(:,:,1),1)*size(frames(:,:,1),2),2);
     frame=frames(:,:,j);
    ndx=0;      % index number of points in the outcome vector 
    Tr=TrReff(:,:,j);Tt=TtReff(:,:,j);
   for ii=1:size(frame,2)     %col, x
      for jj=1:size(frame,1)      %row, y      
            ndx=ndx+1;
            StabCoords(ndx,:)=(Tr*([ii; jj])+Tt);      
       end
    end
    Im_out = Bil_Interp(frame, size(frame,1) , size(frame,2), StabCoords(:,1), StabCoords(:,2));   %  Bil_Interp(Image, Rows, Cols, Px, Py);
    Im_out=reshape(Im_out,size(frames(:,:,1)));
    StabilizedFrames=cat(3,StabilizedFrames,Im_out);    
end
for j=2:size(StabilizedFrames,3)    % the first is just a double for the second index
    figure; 
    imshow(StabilizedFrames(:,:,j));     title(num2str(j));    
    pause(0.15);
end