%% hw3 - question 2 section 3, based on sections 1+2 - image pyramids
close all; clear all; clc
% Load image
im1='focus1.tif';  im2='focus2.tif';
% im1='testing\20131224_222430.jpg';     % just a few home trials
% im2='testing\20131224_222425.jpg';
% im1='testing\20131224_222510.jpg';
% im2='testing\20131224_222517.jpg';
% im1='testing\DSCF8364.jpg';
% im2='testing\DSCF8365.jpg';
im1='testing\20131230_224755.jpg';
im2='testing\20131230_224759.jpg';
G0 = im2double((imread(im1)));    %rgb2gray
G0 = cat(3,G0, im2double((imread(im2))));     %rgb2gray

%% Build Gaussian Pyramid , with 4 levels
% computes aGaussian pyramid reduction or expansion of A by one level. direction can be 'reduce' or 'expand'.
% impyramid uses the kernel specified on page 533 of the Burt and Adelson paper 
G1 = impyramid(G0, 'reduce');
G2 = impyramid(G1, 'reduce');
G3 = impyramid(G2, 'reduce');
%% Build Laplacian Pyramid , with 4 levels
% (using the above Gaussian pyramid levels)
tmp = impyramid(G1, 'expand');  L0=G0(1:size(tmp,1),1:size(tmp,2),:) - tmp;
tmp = impyramid(G2, 'expand');  L1= G1(1:size(tmp,1),1:size(tmp,2),:)- tmp;
tmp = impyramid(G3, 'expand');  L2= G2(1:size(tmp,1),1:size(tmp,2),:)- tmp;
L3= G3;
%% printing pyramids levels
for i=1 : 6     % 2, or 6
figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
title('top line - gausians pyramid levels. buttom line - laplacian pyaramid levels');
subplot(2,4,1);imshow(G0(:,:,i));title(['G0 (' num2str(size(G0,1)) ' x ' num2str(size(G0,2)) ')'])
subplot(2,4,2);imshow(G1(:,:,i));title(['G1 (' num2str(size(G1,1)) ' x ' num2str(size(G1,2)) ')'])
subplot(2,4,3);imshow(G2(:,:,i));title(['G2 (' num2str(size(G2,1)) ' x ' num2str(size(G2,2)) ')'])
subplot(2,4,4);imshow(G3(:,:,i));title(['G3 (' num2str(size(G3,1)) ' x ' num2str(size(G3,2)) ')'])

subplot(2,4,5) ;imshow(L0(:,:,i));title(['L0 (' num2str(size(L0,1)) ' x ' num2str(size(L0,2)) ')'])
subplot(2,4,6) ;imshow(L1(:,:,i));title(['L1 (' num2str(size(L1,1)) ' x ' num2str(size(L1,2)) ')'])
subplot(2,4,7) ;imshow(L2(:,:,i));title(['L2 (' num2str(size(L2,1)) ' x ' num2str(size(L2,2)) ')'])
subplot(2,4,8) ;imshow(L3(:,:,i));title(['L3 (' num2str(size(L3,1)) ' x ' num2str(size(L3,2)) ')'])
end

% figure;surf(abs(L2(:,:,1)));  figure;surf(abs(L2(:,:,2))); % 5/100 seems to be a nice minimum . - not relevant
%% masking the levels by a 'frequency' conditions
R0=[];R1=[];R2=[];
for i=1:3
mask0=abs(L0(:,:,i))>abs(L0(:,:,i+3));   L0masked=L0(:,:,i).*mask0 + L0(:,:,i+3).*(1-mask0);
mask1=abs(L1(:,:,i))>abs(L1(:,:,i+3));   L1masked=L1(:,:,i).*mask1 + L1(:,:,i+3).*(1-mask1);
mask2=abs(L2(:,:,i))>abs(L2(:,:,i+3));   L2masked=L2(:,:,i).*mask2 + L2(:,:,i+3).*(1-mask2);
mask3=abs(L3(:,:,i))>abs(L3(:,:,i+3));   L3masked=L3(:,:,i).*mask3 + L3(:,:,i+3).*(1-mask3);
% imshow(mask2)
%% Reconstruction from Laplacian Pyramid
tmp= impyramid(L3masked, 'expand'); 
R2 = cat(3,R2, L2masked(1:size(tmp,1),1:size(tmp,2)) + tmp);
tmp=impyramid(R2, 'expand');
R1 = cat(3,R1, L1masked(1:size(tmp,1),1:size(tmp,2)) + tmp);
tmp=impyramid(R1, 'expand');
R0 = cat(3,R0, L0masked(1:size(tmp,1),1:size(tmp,2)) + tmp);
end

figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
subplot(2,2,1);imshow(G0(:,:,1:3));title('Original 1')
subplot(2,2,3); %figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
imshow(G0(:,:,4:6));title('Original 2')
subplot(2,2,[2 4]);imshow(R0); title('Reconstructed togrther')

% figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
% imshow(R0); title('Reconstructed togrther');
