%% hw3 - question 2 - image pyramids
close all
clear
clc
% Load image
G0 = im2double(imread('mandril.tif'));
G0 = cat(3,G0, im2double(imread('toucan.tif')));

%% section 1 - Build Gaussian Pyramid , with 5 levels
% computes aGaussian pyramid reduction or expansion of A by one level. direction can be 'reduce' or 'expand'.
% impyramid uses the kernel specified on page 533 of the Burt and Adelson paper 
G1 = impyramid(G0, 'reduce');
G2 = impyramid(G1, 'reduce');
G3 = impyramid(G2, 'reduce');
G4 = impyramid(G3, 'reduce');
%% Build Laplacian Pyramid , with 5 levels
% (using the above Gaussian pyramid levels)
L0=G0(1:end-1,1:end-1,:) - impyramid(G1, 'expand'); 
L1= G1(1:end-1,1:end-1,:) - impyramid(G2, 'expand');
L2= G2(1:end-1,1:end-1,:) - impyramid(G3, 'expand');
L3= G3(1:end-1,1:end-1,:) - impyramid(G4, 'expand');
L4= G4;
%% printing pyramids levels
for i=1 : 2
figure
title('top line - gausians pyramid levels. buttom line - laplacian pyaramid levels');
subplot(2,5,1);imshow(G0(:,:,i));title('G0 (256 x 256)')
subplot(2,5,2);imshow(G1(:,:,i));title('G1 (128 x 128)')
subplot(2,5,3);imshow(G2(:,:,i));title('G2 (64 x 64)')
subplot(2,5,4);imshow(G3(:,:,i));title('G3 (32 x 32)')
subplot(2,5,5);imshow(G4(:,:,i));title('G4 (16 x 16)')

subplot(2,5,6);imshow(L0(:,:,i));title('L0 (256 x 256)')
subplot(2,5,7);imshow(L1(:,:,i));title('L1 (128 x 128)')
subplot(2,5,8);imshow(L2(:,:,i));title('L2 (64 x 64)')
subplot(2,5,9);imshow(L3(:,:,i));title('L3 (32 x 32)')
subplot(2,5,10);imshow(L4(:,:,i));title('L4 (16 x 16)')
end

%% section 2 - Reconstruction from Laplacian Pyramid
R3 =  L3 + impyramid(L4, 'expand');
R2 =  L2(1:end-2  ,1:end-2 ,:) + impyramid(R3, 'expand');
R1 =  L1(1:end-6  ,1:end-6 ,:) + impyramid(R2, 'expand');
R0 =  L0(1:end-14,1:end-14,:) + impyramid(R1, 'expand');

% figure     % watch the histogram narrowing-down
% subplot(1,2,1);hist(G0(:),256);title('Histogram of G0')
% subplot(1,2,2);hist(L0(:),256);title('Histogram of L0')

for i=1:2
    diff=(G0(1:size(R0,1),1:size(R0,2),i)-R0(:,:,i));
    disp(norm(diff));
    figure;mesh(diff);title ('original to reconstruct differences');
figure
subplot(1,2,1);imshow(G0(:,:,i));title('Original')
subplot(1,2,2);imshow(R0(:,:,i));title('Reconstructed')
end

% it can be seen that the reconstract is smaller than the original, but in
% that remained size - it is identical except for the boundaries.
