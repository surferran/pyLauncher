function Im_out = Bil_Interp(Image, Rows, Cols, Px, Py)
% BIL_INTERP Bilinear Interpolation of image coordinates.
%
% Image - Non-stabilized source image. 
% rows, cols - Size of the reference image for the destination.
% Px, Py - Non-integer coordinate grids in the non-stabilized image.
%          These are received from applying the transformation on an
%          integer coourdinate grids in the size of the destination.
%
% Im_out - Stabilized destination image.
%

Image = double(Image);

% Prevent invalid indices from tampering with the process
Px_invalid = Px<1 | Px>Cols;
Py_invalid = Py<1 | Py>Rows;
Px(Px_invalid) = 1;
Py(Py_invalid) = 1;

% Calculate value retrieval index and offsets from integer coordinates
index = (floor(Px)-1)*Rows + floor(Py);
Px_offset = Px - floor(Px);
Py_offset = Py - floor(Py);

% Calculate the bilinear value
Im_out = Image(index).*(1-Py_offset).*(1-Px_offset) + ...
         Image(index+1).*Py_offset.*(1-Px_offset) + ...
         Image(index+Rows).*(1-Py_offset).*Px_offset + ...
         Image(index+Rows+1).*Py_offset.*Px_offset;
     
% Mark out invalid coordinates
Im_out(Px_invalid | Py_invalid) = NaN;
Im_out = round(Im_out);
Im_out(Im_out<0) = 0;
Im_out(Im_out>255) = 255;
     
return;