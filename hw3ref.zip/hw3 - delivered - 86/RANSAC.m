function [A,b] = RANSAC(Cref_match, Cin_match)
% RANSAC Outlier removal using the RANSAC algorithm.
%
% Cref_match - 2D vector containing the matched feature points from the reference image.
% Cin_match - 2D vector containing the matched feature points from the non-stabilized image.
%
%
% A - Affine transformation matrix A.
% b - Affine transformation vector b.
%
% Cref_match=FPrefShow;   % for debug
% Cin_match=FPshow(:,:,2);   % for debug
Dmax=3;                     % enough deviation for inliner group
chkSize=20;
MaxInPoints=0;  inlinerGroup=[];
for ndx=1:chkSize          % number of triels to conduct
 % getting 3 random numbers. no doubles
 rnd3=[]; 
 while length(unique(rnd3))<3
  rnd3=round(random('Uniform',1,length(Cref_match),[1,3]));
 end   
 Ref3=Cref_match(rnd3,:);  Pnt3=Cin_match(rnd3,:);
 [Tr,Tt]=findTransformation(Ref3, Pnt3);
 % check inliner group size and points
 insidePoints=0;  TmpInlinerGroup=[];
 for j=1:length(Cref_match)
    X=(Tr*(Cref_match(j,:))'+Tt);   % transform base to target
    dist=norm(Cin_match(j,:) - X');          % sum(abs(v).^2)^(1/2).
    if dist<=Dmax
        insidePoints=insidePoints+1;
        TmpInlinerGroup=vertcat(TmpInlinerGroup, j);     % keeps indexes only
    end
 end
 if insidePoints>MaxInPoints
     MaxInPoints=insidePoints;
     inlinerGroup=TmpInlinerGroup;
 end
end
% now finds the accurate transformation by the most qualified feature points
 [A,b]=findTransformation( Cref_match(inlinerGroup,:), Cin_match(inlinerGroup,:));