function D = synonyms(D);

