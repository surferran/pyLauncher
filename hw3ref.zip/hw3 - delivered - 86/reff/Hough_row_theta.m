% Hough transform - row & theta plane
clear all
close all
clc
N=101;
P=randperm(N);
P=P(1:20);
Z=zeros(1,N);
Z(P)=1;
I=diag(Z);
imshow(I,[]);
H=zeros(2*N);
theta=linspace(0, pi,2*N);
row=linspace(-2*N+1,2*N,2*N);
for n=1:N^2
    pixel=I(n);
    if pixel==0
        continue;
    end
    [y x]=ind2sub([N,N],n);
    y=N-y+1; % mirror the Y axis of matlab
    for t=1:2*N
        r=x*cos(theta(t))+y*sin(theta(t));
        row_index=find(row>r);
        row_index=row_index(1);
        H(row_index-1,t)=H(row_index-1,t)+1;
    end
end
subplot(1,2,1);imshow(I);xlabel('x');ylabel('y')
subplot(1,2,2);imshow(uint8(H*40));xlabel('\theta');ylabel('\rho')
peak = find(H==max(max(H)));
peak = peak(1);
[i,j]=ind2sub([2*N 2*N],peak);
fprintf('row=%d theta=%d\n',row(i),theta(j)*180/pi)
