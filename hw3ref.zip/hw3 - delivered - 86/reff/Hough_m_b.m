% Hough transform - m & b plane
clear all
close all
clc
N=101;
P=randperm(N);
P=P(1:20);
Z=zeros(1,N);
Z(P)=1;
I=diag(Z);
imshow(I,[]);
H=zeros(2*N);
m=linspace(-2,2,2*N);
b=linspace(-3*N,3*N,2*N);
for n=1:N^2
    pixel=I(n);
    if pixel==0
        continue;
    end
    [y x]=ind2sub([N,N],n);
    y=N-y+1; % mirror the Y axis of matlab
    for m_index=1:2*N
        est_b=-x*m(m_index)+y;
        b_index=find(b>est_b);
        b_index=b_index(1)-1;
        H(b_index,m_index)=H(b_index,m_index)+1;
    end
end
subplot(1,2,1);imshow(I,[]);xlabel('x');ylabel('y')
subplot(1,2,2);imshow(uint8(H*40));xlabel('m');ylabel('b')
peak = find(H==max(max(H)));
peak = peak(1);
[i,j]=ind2sub([2*N 2*N],peak);
fprintf('b=%d m=%d\n',b(i),m(j))
