function [Cref_match Cin_match] = Patch_Match(Iref, Iin, Cref, Cin, L, W)
% PATCH_MATCH automatically match feature points between images.
%
% Iref - Reference image.
% Iin - non-stabilized image.
% Cref - 2D vector containing the feature points from the reference image.
%	 First column will be X, second column Y. (for all 2D vectors)
% Cin - 2D vector containing the feature points from the non-stabilized image.
% L - Search window size.
% W - SSD window size
%
%
% Cref_match - 2D vector containing the matched feature points from the reference image.
% Cin_match - 2D vector containing the matched feature points from the non-stabilized image.
%


% start compering for each picture
for i=1:size(finalFP,1)      % for each coordinate pair
    xl=finalFP(i,1)-floor(L/2);      % corners of the comperison window
    xh=finalFP(i,1)+floor(L/2);    
    yl=finalFP(i,2)-floor(L/2);    
    yh=finalFP(i,2)+floor(L/2);
    chk=FPs(:,:,2);   % 2 will be j - num of pic. no [0 0] problem
    ndx=((chk>=ones(length(chk),1)*[xl yl]) & (chk<=ones(length(chk),1)*[xh yh]));
    cors=find(ndx(:,1) & ndx(:,2)) ;         % index of the line in 'chk' -> into corresponds
    if isempty(cors)
        if i>1 & i<length(finalFP)
          finalFP=finalFP([1:i-1,i+1:end],:);
        else
          if i==1
              finalFP=finalFP(2:end,:);
          else
              finalFP=finalFP(1:end-1);
          end
        end  
    else   % of empty condition
%         min ssd ((weighted) summed square difference) of all foundings

      Essd=sum(sum(W*(imgs(xl:xh,yl:yh,1)-imgs(xl:xh,yl:yh,2)).^2))
    end
end
