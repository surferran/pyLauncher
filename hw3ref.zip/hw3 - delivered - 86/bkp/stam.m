% stam to check frames
StabilizedFrames=imgs(:,:,1);
StabCoords=zeros(size(frame,1)*size(frame,2),2);
for j=1:6
     frame=I{1+j};  
    ndx=1;
    Tr=TrReff(:,:,j);Tt=TtReff(:,:,j);
   for ii=1:size(frame,2)     %col, x
      for jj=1:size(frame,1)      %row, y
            StabCoords(ndx,:)=(Tr*([ii; jj])+Tt);            
            ndx=ndx+1;
       end
    end
    Im_out = Bil_Interp(frame, size(frame,1) , size(frame,2), StabCoords(:,1), StabCoords(:,2));   %  Bil_Interp(Image, Rows, Cols, Px, Py);
    Im_out=reshape(Im_out,size(imgs(:,:,1)));
    StabilizedFrames=cat(3,StabilizedFrames,Im_out);    
end
for j=1:length(I)
%     frame=I{j};   
    figure; 
    imshow(StabilizedFrames(:,:,j));     title(num2str(j));    
    pause(0.0715);
end