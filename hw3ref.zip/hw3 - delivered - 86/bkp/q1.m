%% solution for - Question 1 (Matlab): Scale Invariance

%% section 1.
% Load the image. We will be focusing on a circle on the right wing, indexing at (106,194).
% Show a 21x21 close up image of the focus point. How can you describe this image?
clear all; close all; clc
importfile('butterfly.pgm');
zoomSize=21; Zx=106; Zy=194;    % zoomed area parameters
butt_zoom21=q1section1(butterfly,zoomSize,Zx,Zy,1);

%% section 2 + 3
% Laplacian of Gaussian operator (1) and its scale normalized version (2)
filt_size=27;
sigma_vec=1:2:10;     % 0.5 is the filter default     % 1:0.2:10;
figure;
for sigma=sigma_vec
 logF=fspecial('log',filt_size,sigma);      % G function of the help explanation
 conv_vec=[1 -2 1];
% % STAM section
% filt29=conv2(conv_vec,conv_vec',logF);
% filt25=filt29(3:27,3:27);
% % imFilt=imfilter(butterfly,filt25);
% imFilt=conv2(butterfly,filt25);    % !! intersting result
% figure;imshow(imFilt);
% % finish of STAM section
 logFxx=conv2(conv_vec,logF);     % trim 4 on sides, so also 2 in hight. because diffs garbage (artifacts)
 logFxx=logFxx(2:end-1,3:end-2);
 logFyy=conv2(conv_vec',logF);     % trim 4 in hight, so also 2 in sides. because diffs garbage (artifacts)
 logFyy=logFyy(3:end-2,2:end-1);
 F1=logFxx+logFyy; 
 F2=(logFxx+logFyy)/sigma/sigma; 
 figure;         % do only partial
 subplot(1,2,1); surf(F1);               % length(sigma_vec) , sigma,;  sigma+1
 subplot(1,2,2); surf(F2);
end
% it can be seen that the negative part is getting out of the borders when
% the sigma is getting bigger. so its profile is looking just like a
% gausian. between the regular filter and it's normalized partner - they
% ofcourse look the same but the normalized has much a lower scale of
% values.
% %  imFilt1=conv2(butterfly,F1);    
% %  figure;imshow(imFilt1);
% %  imFilt2=conv2(butterfly,F2);    
% %  figure;imshow(imFilt2);

%% section 4 - imresize
butt_halfed=imresize(butterfly, 0.5);   % figure;imshow(butt_halfed);
butt_zoom11=q1section1(butt_halfed,zoomSize,Zx,Zy,2);

