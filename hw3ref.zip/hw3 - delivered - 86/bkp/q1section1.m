function [im_zoomed]=q1section1(img_org,zoomSize,Zx,Zy,scale)
figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
subplot(1,2,1);
imshow(img_org); title('Orginal image' ) ; 
zoomSize=floor(zoomSize/scale); Zx=floor(Zx/scale); Zy=floor(Zy/scale);
rectangle('Position',[Zy-zoomSize/2,Zx-zoomSize/2,zoomSize,zoomSize],'EdgeColor','r');
zoomArea=-floor(zoomSize/2):floor(zoomSize/2);
im_zoomed=img_org(Zx+zoomArea,Zy+zoomArea);
subplot(1,2,2); 
imshow(im_zoomed);title('Zoomed image' ) ; 
% this zoomed image is like a circle trimmed in a boundary of lines.
end