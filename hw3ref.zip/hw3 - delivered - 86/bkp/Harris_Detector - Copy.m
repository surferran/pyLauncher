function Interest_Points = Harris_Detector(Image, Thresh, Sigma, N)
% HARRIS_DETECTOR Detects harris feature points - corner detector - in an image.
%
% Image - Input image.
% Thresh - Detector threshold value.
% Sigma - Gaussian standard deviation.
%	  The matrix A is calculated using gaussian smoothing.
%	  sigma should be in the range [1,2].
% N - Number of feature point to return.
%
% Interest_Points - 2D array containing the detected feature points.
%		    First column will be X, second column Y.
%

% reff
I = im2single(imread('circuit.tif'));
cornerDetector = vision.CornerDetector('Method','Local intensity comparison (Rosten & Drummond)');
% cornerDetector = vision.CornerDetector('Harris corner detection (Harris& Stephens)');
% cornerDetector = vision.CornerDetector;
 pts = step(cornerDetector, I); 
color = [1 0 0];
drawMarkers = vision.MarkerInserter('Shape', 'Circle', 'BorderColor', 'Custom', 'CustomBorderColor', color);
J = repmat(I,[1 1 3]); 
J = step(drawMarkers, J, pts);
figure;imshow(J); title ('Corners detected in a grayscale image'); 


% reff
I = checkerboard(50,2,2);
C = corner(I,100);
imshow(I);
hold on
plot(C(:,1), C(:,2), 'r*');