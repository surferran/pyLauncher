%% q3
% You will implement two ways for matching feature
% points: Manual matching in item 2, and automatic matching in item 5. Since the automatic
% matching may sometime fail, you will implement an algorithm in item 6 to use only matched
% feature points with a high probability to be correct.

Disp_Images;     % returns 'imgs' array  % includes Harris_Detector implementation and FPs 3D array

% Image=imgs(:,:,1);
% thePoints=Harris_Detector(Image, Thresh, Sigma, N);
% imshow(Image);hold on
% plot(thePoints(:,1),thePoints(:,2),'GX','linewidth',1.5)    %,'rO')    

%% ref points from manual image #1
thePoints([ 54 81 97 93 45 16 ],:)   % after plot number 1
% =>  by manual cut & paste or probing
 ref1Points= [241    37 ;   381    33;   492   216;   458   329;   179   327;    65   333];
 ref2Points= [241 39; 380 35; 491 218; 458 331; 178 329; 64 334];
 ref3Points= [243 44; 383 40; 493 223; 459 336; 179 334; 66 339];
 ref4Points= [247 37; 387 34; 497 217; 463 330; 183 327; 70 332];
 ref5Points= [243 40; 382 37; 492 220; 459 332; 178 330; 65 334];
 ref6Points= [238 36; 377 32; 488 214; 454 327; 174 327; 60 332];
 ref7Points= [240 33; 380 28; 491 211; 458 324; 177 324; 64 329]; 
refPoints=cat(3,[],ref1Points,ref2Points,ref3Points,ref4Points,ref5Points,ref6Points,ref7Points);

%% part 2
types={'bo'; 'rx'; 'k*'; 'co' ; 'yx'; 'g*'; 'm+'};
for j=1:length(I)
    frame=I{j};   
    figure; 
    imshow(frame);     title(num2str(j));  
    hold on;
    plot(refPoints(:,1,j),refPoints(:,2,j),types{j},'linewidth',1.5)    %,'rO')   
end
%% part 3 - LS formulation
% we have 6 unknowns for each transformation. reff pic to n=2..6 pic.
% unkowns are a11 a12 a21 a22 b1 b2 for each 2 pictures set.
% x1=a1 Xr1 + a2 Xr2 + b1
% x2=a3 Xr1 + a4 Xr2 + b2
% X = A B . B=[a1 a2 a3 a4 b1 b2] is the unkown
A=[ refPoints(1,1,1) refPoints(1,2,1)             0                        0                  1           0
              0                             0          refPoints(1,1,1)  refPoints(1,2,1)        0          1
      refPoints(2,1,1) refPoints(2,2,1)             0                        0                  1           0
              0                             0          refPoints(2,1,1)  refPoints(2,2,1)        0          1
      refPoints(3,1,1) refPoints(3,2,1)             0                        0                  1           0
              0                             0          refPoints(3,1,1)  refPoints(3,2,1)        0          1
      refPoints(4,1,1) refPoints(4,2,1)             0                        0                  1           0
              0                             0          refPoints(4,1,1)  refPoints(4,2,1)        0          1
      refPoints(5,1,1) refPoints(5,2,1)             0                        0                  1           0
              0                             0          refPoints(5,1,1)  refPoints(5,2,1)        0          1
      refPoints(6,1,1) refPoints(6,2,1)             0                        0                  1           0
              0                             0          refPoints(6,1,1)  refPoints(6,2,1)        0          1        
              ];
% A is constant for all LS problems. X is chnging and therfore B .  
TrReff=[]; TtReff=[];
figure;
for j=2:7
X=refPoints(:,:,j)' ;  X=X(:);   % flatten the matrix to vector
%        B=inv(A)*X - A not symetric
% solving with standard LS solution. X=A B -> Bestimate=LS=inv(A' A) A' X
LS=inv((A')*A) *(A')*X;
Tr=[LS(1) LS(2) ; LS(3) LS(4)];  % rotation
Tt=[LS(5) ; LS(6)];    % translation
disp(Tr);disp(Tt);
TrReff=cat(3,TrReff,Tr); 
TtReff=cat(3,TtReff,Tt);

   % some figurative way to show the change in coordinates origine for each picture frame
%RGB. inside the loop because speed is no matter here.
grayMiddle=[.5, .5 ,.5]; black=[0 0 0]; red=[1 0 0]; yellow=[1 1 0];
green=[0 1 0]; cyan=[0 1 1]; blue=[0 0 1]; magenta=[1 0 1]; white=[1 1 1];
colors=[grayMiddle ; black; red; yellow; green; cyan; blue; magenta; white]; 

coor1o=[0.350 .150];  coor1y= [.35 .865]; coor1x= [.865 .15];
annotation('textarrow',[coor1o(1) coor1y(1)], [coor1o(2) coor1y(2)] , 'String', ['coor of pic 1                         '],'Color', colors(1,:) );
annotation('arrow',[coor1o(1) coor1x(1)], [coor1o(2) coor1x(2)],'Color', colors(1,:) );
cO=(Tr*(coor1o.*size(frame))'+Tt)./size(frame)';    % normalizing to [1,1] max
cX=(Tr*(coor1x.*size(frame))'+Tt)./size(frame)'; 
cY=(Tr*(coor1y.*size(frame))'+Tt)./size(frame)'; 
annotation('textarrow',[cO(1) cY(1)], [cO(2) cY(2)] , 'String', ['coor of pic ' num2str(j) '                         '],'Color', colors(j,:) );
annotation('arrow',[cO(1) cX(1)], [cO(2) cX(2)] ,'Color', colors(j,:) );
    % other option to display is with plot (o1,o(j),y(j),o(j),x(j)) '-*' points in differ colors, which
    % matlab will allow to zoom in and note the differences.    
end    % end of j=2:7
%% section 4
% if previusly we first rotated the point coordinates and then translated
% it - now we need first to translate back and then rotate with inverse.
% StabilizedFrames=zeros(size(imgs)); % never mind the redundant 1st and last - not usefull
StabilizedFrames=imgs(:,:,1);
StabCoords=zeros(size(frame,1)*size(frame,2),2);
for j=1:6
     frame=I{1+j};  
    ndx=1;
    Tr=TrReff(:,:,j);Tt=TtReff(:,:,j);
   for ii=1:size(frame,2)     %col, x
      for jj=1:size(frame,1)      %row, y
            StabCoords(ndx,:)=(Tr*([ii; jj])+Tt);            
            ndx=ndx+1;
       end
    end
    Im_out = Bil_Interp(frame, size(frame,1) , size(frame,2), StabCoords(:,1), StabCoords(:,2));   %  Bil_Interp(Image, Rows, Cols, Px, Py);
    Im_out=reshape(Im_out,size(imgs(:,:,1)));
    StabilizedFrames=cat(3,StabilizedFrames,Im_out);    
end
for j=1:length(I)
    frame=I{j};   
    figure; 
    imshow(StabilizedFrames(:,:,j));     title(num2str(j));    
    pause(0.0715);
end

%% section 5 - 
% will use image content similarity in the local feature point neighborhood.
[I,J] = find(FPs(:,:,1)~=0);      
finalFP=FPs(1:max(I),:,1)  ;    % baseline of the feature points
L=11;         %--- window  enought for expected movements. 11 is very strict. need bigger later on
W=6;    % size assuming not exact calculation of the feature point location. about size of sigma used before
                   % taking W as constant
for ndx=2:7
    [finalFP,ndxFP]=Patch_Match(imgs(:,:,1),imgs(:,:,ndx),finalFP,FPs(:,:,ndx),L,W);
       % finalFP will be reduced. ndxFP need to be checked later
     FPall(:,:,ndx)=ndxFP;  
end
% [C,ia,ib] = union(A,B,'rows')   % join indexes..
x=union(finalFP,FPall(:,:,2);

