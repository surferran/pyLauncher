function [Tr,Tt]=findTransformation(basePnt, targetPnt)
% we have 6 unknowns for each transformation. base to target picture
% unkowns are a11 a12 a21 a22 b1 b2 for each 2 pictures set.
% x1=a1 Xr1 + a2 Xr2 + b1
% x2=a3 Xr1 + a4 Xr2 + b2
% X = A B . B=[a1 a2 a3 a4 b1 b2] is the unkown
A=[];
for i=1:length(basePnt)
 AtwoLine=[ basePnt(i,1)   basePnt(i,2)             0                        0           1           0
                      0                             0        basePnt(i,1)  basePnt(i,2)        0          1   ];
 A=vertcat(A,AtwoLine);
end
% A is constant for specific LS problem. X is chnging and therfore B .  
X=targetPnt(:,:)' ;  X=X(:);                            % flatten the matrix to vector
% B=inv(A)*X - A not always symetric
% solving with standard LS solution. X=A B -> Bestimate=LS=inv(A' A) A' X
LS=((A')*A) \ (A')*X;                 % inv() * ()
Tr=[LS(1) LS(2) ; LS(3) LS(4)];  % rotation
Tt=[LS(5) ; LS(6)];                   % translation