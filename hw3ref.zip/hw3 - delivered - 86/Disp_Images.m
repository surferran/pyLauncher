close all
clear all
clc

% if 1==1
    load ('inputFiles/Images')     
% else
%     p1_1 = rgb2gray(imread('inputFiles/p1_1.jpg'));
%     p1_2 = rgb2gray(imread('inputFiles/p1_2.jpg'));
%     p1_3 = rgb2gray(imread('inputFiles/p1_3.jpg'));
% %     imshow(p1_1)
%     I={p1_1, p1_2, p1_3};
% end
% return
for j=1:length(I)
    imshow(I{j})
    title(num2str(j))
    pause(0.31)
end


