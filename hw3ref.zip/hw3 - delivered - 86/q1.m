%% solution for - Question 1 (Matlab): Scale Invariance

%% section 1.
% Load the image. We will be focusing on a circle on the right wing, indexing at (106,194).
% Show a 21x21 close up image of the focus point. How can you describe this image?
clear all; close all; clc
importfile('butterfly.pgm');
zoomSize=21; Zx=106; Zy=194;    % zoomed area parameters
butterfly=(butterfly);       % double or im2double are % different. and resulting in different image results.
butt_zoom21=q1section1(butterfly,zoomSize,Zx,Zy,1);

%% section 2 + 3
% Laplacian of Gaussian operator (1) and its scale normalized version (2)

sigma_vec=1:0.2:10;     % 0.5 is the filter default     % 1:0.2:10;
printTotal=7;
[f1,f2]=q1section34(butterfly,sigma_vec,printTotal,Zx,Zy);  % f1,f2 - regular,normalized result

%% section 4 - imresize
butt_halfed=(imresize(butterfly, 0.5));   % figure;imshow(butt_halfed);   % 
butt_halfed=(butt_halfed);  %im2double
butt_zoom11=q1section1(butt_halfed,zoomSize,Zx,Zy,2);

[f3,f4]=q1section34(butt_halfed,sigma_vec,printTotal,floor(Zx/2),floor(Zy/2)); % f3,f4 - regular,normalized result

% it can be seen that smaller sigma gives better results(details) and
% regular better then normalized filter because its higher values
% but normalized filter with smaller sigma might be better than regular
% with bigger sigma - in aspect of enought details and less noise.

%% section 5
% implemented already above

%% section 6 - focus point values through graphs
figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
 subplot(1,2,1);
plot(sigma_vec,f1,'-b*');hold on; plot(sigma_vec,f3,'-r*');    % graphs of the regular filter
legend('f1','f3'); grid on;
title('regular filters as fuction of sigma');
% axis equal 
% figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
 subplot(1,2,2);
plot(sigma_vec,f2,'-b*');hold on; plot(sigma_vec,f4,'-r*');    % graphs of the normalized filter
legend('f2','f4'); grid on;
title('normalized filters as fuction of sigma');

%% section 7
% find the max sigma for each filter
r1=sigma_vec((f2==max(f2)));     % for first pic. but gets smaller values
r2=sigma_vec((f4==max(f4)));
disp (r1);
disp (r2);

figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
subplot(1,2,1); 
imshow(butterfly); title(['Orginal image. R=sigma(max(filter(2)))=' num2str(r1)] ) ; 
rectangle('Position',[Zy-r1/2,Zx-r1/2,r1,r1],'EdgeColor','r','Curvature',1);
subplot(1,2,2);
imshow(butt_halfed); title(['Smaller image. R=sigma(max(filter(2)))=' num2str(r2)] ) ; 
rectangle('Position',[Zy/2-r2/2,Zx/2-r2/2,r2,r2],'EdgeColor','r','Curvature',1);
