function [focPoint1,focPoint2]=q1section34(img,sigma_vec,printTotal,Fx,Fy)
filt_size=27;
ndx=0; each=ceil(length(sigma_vec)/printTotal);
focPoint1=zeros(1,length(sigma_vec));focPoint2=focPoint1;    % init
for sigma=sigma_vec
 ndx=ndx+1;
 logF=fspecial('gaussian',filt_size,sigma);      % G function of the help explanation   'log'
 conv_vec=[1 -2 1]; 
 logFxx=conv2(conv_vec,logF)   ;
 logFxx=logFxx(2:end-1,3:end-2);  % trim 4 on sides, so also 2 in hight. because diffs garbage (artifacts)
 logFyy=conv2(conv_vec',logF)  ;
 logFyy=logFyy(3:end-2,2:end-1);  % trim 4 in hight, so also 2 in sides. because diffs garbage (artifacts)
 
 F1=logFxx+logFyy;
 F2=(logFxx+logFyy)*sigma*sigma;    % normalized
 
%  F1=fspecial('log',filt_size,sigma);      % logF=option to print for  comparisions
 
 imFilt1=(conv2((img),F1));    % im2double
 imFilt2=(conv2((img),F2));          %% %% im2uint8
 focPoint1(ndx)=imFilt1(Fx,Fy);
 focPoint2(ndx)=imFilt2(Fx,Fy);
 
 if mod (ndx,each)==0    % print only part of the batch
  figure('units','normalized','outerposition',[0 0.0 1 1]);    % maximize window
  subplot(2,2,1); surf(F1); title('F1 ');             % length(sigma_vec) , sigma,;  sigma+1
  subplot(2,2,2); surf(F2); title('F2 ');
  subplot(2,2,3); imshow((imFilt1)); title('F1 filtered');
  subplot(2,2,4); imshow((imFilt2)); title('F2 filtered');
 end
end
% it can be seen that the negative part is getting out of the borders when
% the sigma is getting bigger. so its profile is looking just like a
% gausian. between the regular filter and it's normalized partner - they
% ofcourse look the same but the normalized has much a lower scale of
% values.
end