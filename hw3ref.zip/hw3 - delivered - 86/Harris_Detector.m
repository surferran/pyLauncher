function Interest_Points = Harris_Detector(Image, Thresh, Sigma, N)
% HARRIS_DETECTOR Detects harris feature points - corner detector - in an image.
%
% Image - Input image.
% Thresh - Detector threshold value.
% Sigma - Gaussian standard deviation.
%	  The matrix A is calculated using gaussian smoothing.
%	  sigma should be in the range [1,2].
% N - Number of feature point to return.
%
% Interest_Points - 2D array containing the detected feature points.
%		    First column will be X, second column Y.
%

% r - # of pixels for radius % r-number of pixels around to comute. taking 5 as a constant, rather then
% some percentage of relation to image size
r=5;     
% derivatives
dx = [-1 0 1; -1 0 1; -1 0 1]; % masking
dy = dx';
Ix = conv2(Image, dx, 'same');   
Iy = conv2(Image, dy, 'same');
g = fspecial('gaussian',max(1,fix(6*Sigma)), Sigma); % Gaussien Filter   , 6 sigma for good outcome relation
 % elements of the auto-correlation matrix A 
Ix2 = conv2(Ix.^2, g, 'same');  
Iy2 = conv2(Iy.^2, g, 'same');
Ixy = conv2(Ix.*Iy, g,'same');
%   equation 4.9 in the book . calculating det(A) - alpha*trace(A)^2.
%   taking alpha according to the book
alpha = 0.06 ;
R11 = (Ix2.*Iy2 - Ixy.^2) - alpha*(Ix2 + Iy2).^2;
R11=(1000/max(max(R11)))*R11;   % normalize
 R=R11;
 % want to eliminate neighbours . by very good function for that: ordfilt2(A, order, domain) - 2-D order-statistic filtering
 sze = 2*r+1; 
 MX = ordfilt2(R,sze^2,ones(sze));     % same effect of imdilate
 R11 = (R==MX)&(R>Thresh);   % getting the FPs with the minimum threshold limit
 r11trimmed=R11(r-1:size(R11,1)-r-1 , r-1:size(R11,2)-r-1);
    Ncount=sum(sum(r11trimmed));
 display(Ncount);   
 
 [FPy,FPx]=find(r11trimmed);    %  [row,col] = find(X, ...)
 Interest_Points= [FPx,FPy]+r;
 