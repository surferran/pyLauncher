function [Cref_match, Cin_match] = Patch_Match(Iref, Iin, Cref, Cin, L, W)
% PATCH_MATCH automatically match feature points between images.
%
% Iref - Reference image.
% Iin - non-stabilized image.
% Cref - 2D vector containing the feature points from the reference image.
%	 First column will be X, second column Y. (for all 2D vectors)
% Cin - 2D vector containing the feature points from the non-stabilized image.
% L - Search window size.
% W - SSD window size
%
%
% Cref_match - 2D vector containing the matched feature points from the reference image.
% Cin_match - 2D vector containing the matched feature points from the non-stabilized image.
%
% Cin_match=[]; Cref_match=[];    % init;
pntNdx=0;    Cin_match=zeros(200,2);
    Cref_match=Cin_match;
% start compering for each picture
for i=1:size(Cref ,1)      % for each coordinate pair
    xl=Cref(i,1)-floor(L/2);      % corners of the comperison window. same coordinates for both pictures
    xh=Cref(i,1)+floor(L/2);    
    yl=Cref(i,2)-floor(L/2);    
    yh=Cref(i,2)+floor(L/2); 
%     if xl<0 , xl=0 ; end
%     if yl<0 , yl=0 ; end
%     if xl>size(Iin,2)-floor(L/2)  , xl=size(Iin,2)-floor(L/2) ; end
%     if yl>size(Iin,1)-floor(L/2) , yl=size(Iin,1)-floor(L/2) ; end
     % check points in range of window L
    ndxx=((Cin>=ones(length(Cin),1)*[xl yl]) & (Cin<=ones(length(Cin),1)*[xh yh])); 
    cors=find(ndxx(:,1) & ndxx(:,2))' ;        % index of the line in 'Cin' -> into corresponds    
    if ~isempty(cors) % at least one correspondense 
       %  for those coords that in range - check  min ssd ((weighted) summed square difference) 
      EminNdx=0; Emin=999999;
      for j=cors         %Cin(cors,:))
         l=Cin(j,:)-Cref(i,:)   ;    % l is the u vector= [x y]
         Essd=sum(sum(W*(Iin((yl:yh)+l(2),(xl:xh)+l(1))-Iref(yl:yh,xl:xh)).^2));  % ~d^2
         if Essd<Emin
             Emin=Essd;
             EminNdx=j;
         end
      end
      if EminNdx>0
%          Cin_match=vertcat(Cin_match,Cin(EminNdx,:));  % add point to the returned matchs         
%          Cref_match=vertcat(Cref_match,Cref(i,:));   % add point to the returned matchs
        pntNdx=pntNdx+1;
        Cin_match(pntNdx,:)=Cin(EminNdx,:);
        Cref_match(pntNdx,:)=Cref(i,:);
      end
    end   % end of cors condition - either found a 1-1 match or none for Ref point
end
pntNdx    % for refference
